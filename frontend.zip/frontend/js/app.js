/**
 * CyberStudy - Aplicação JavaScript
 * Funções reutilizáveis para o frontend
 */

// ===== CONFIGURAÇÃO =====

const API_BASE = '/api';
const STORAGE_PREFIX = 'cyberstudy_';

// ===== UTILITÁRIOS =====

/**
 * Obter participantId do localStorage
 */
function getParticipantId() {
    return localStorage.getItem(STORAGE_PREFIX + 'participantId');
}

/**
 * Salvar dados no localStorage
 */
function saveToStorage(key, value) {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
}

/**
 * Recuperar dados do localStorage
 */
function getFromStorage(key) {
    const data = localStorage.getItem(STORAGE_PREFIX + key);
    return data ? JSON.parse(data) : null;
}

/**
 * Fazer requisição à API
 */
async function apiCall(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method,
            headers: { 'Content-Type': 'application/json' },
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        const response = await fetch(API_BASE + endpoint, options);
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.error || 'Erro na requisição');
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Mostrar notificação
 */
function showNotification(message, type = 'info') {
    const alertClass = `alert alert-${type}`;
    const alertDiv = document.createElement('div');
    alertDiv.className = alertClass;
    alertDiv.textContent = message;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '1000';
    alertDiv.style.maxWidth = '400px';
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

/**
 * Validar formulário
 */
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = 'var(--danger-color)';
            isValid = false;
        } else {
            input.style.borderColor = '';
        }
    });
    
    return isValid;
}

/**
 * Atualizar barra de progresso
 */
function updateProgress(current, total) {
    const percentage = (current / total) * 100;
    const progressFill = document.querySelector('.progress-fill');
    if (progressFill) {
        progressFill.style.width = percentage + '%';
    }
    
    // Atualizar steps
    const steps = document.querySelectorAll('.progress-step');
    steps.forEach((step, index) => {
        step.classList.remove('active', 'completed');
        if (index < current) {
            step.classList.add('completed');
        } else if (index === current - 1) {
            step.classList.add('active');
        }
    });
}

/**
 * Navegar para próxima página
 */
function navigateToPage(pageName) {
    window.location.href = `/pages/${pageName}.html`;
}

/**
 * Voltar para página anterior
 */
function goBack() {
    window.history.back();
}

// ===== ESCALAS PSICOLÓGICAS =====

/**
 * Calcular score de uma escala
 */
function calculateScaleScore(responses) {
    return Object.values(responses).reduce((sum, val) => sum + parseInt(val || 0), 0);
}

/**
 * Salvar respostas de escala
 */
async function saveScaleResponses(scaleName, responses) {
    try {
        const participantId = getParticipantId();
        const endpoint = `/study/save-${scaleName.toLowerCase()}/${participantId}`;
        
        const result = await apiCall(endpoint, 'POST', { responses });
        
        // Salvar no localStorage também
        saveToStorage(`${scaleName}_responses`, responses);
        
        return result;
    } catch (error) {
        showNotification(`Erro ao salvar ${scaleName}`, 'error');
        throw error;
    }
}

// ===== IGT (IOWA GAMBLING TASK) =====

/**
 * Inicializar IGT
 */
function initializeIGT() {
    return {
        trials: [],
        balance: 2000,
        currentTrial: 0,
        startTime: Date.now(),
    };
}

/**
 * Executar tentativa do IGT
 */
function executeIGTTrial(igt, deckChosen) {
    const trial = {
        trialNumber: igt.currentTrial + 1,
        deckChosen: deckChosen,
        gain: 0,
        loss: 0,
        netGain: 0,
        runningTotal: igt.balance,
        responseTime: Date.now() - igt.startTime,
    };
    
    // Lógica dos baralhos (conforme protocolo IGT original)
    const decks = {
        'A': { gain: 100, loss: -150, frequency: 0.5 },
        'B': { gain: 100, loss: -1250, frequency: 0.1 },
        'C': { gain: 50, loss: -50, frequency: 0.5 },
        'D': { gain: 50, loss: -25, frequency: 0.8 },
    };
    
    const deck = decks[deckChosen];
    trial.gain = deck.gain;
    trial.loss = Math.random() < deck.frequency ? deck.loss : 0;
    trial.netGain = trial.gain + trial.loss;
    
    igt.balance += trial.netGain;
    trial.runningTotal = igt.balance;
    
    igt.trials.push(trial);
    igt.currentTrial++;
    
    return trial;
}

/**
 * Salvar resultados do IGT
 */
async function saveIGTResults(igt) {
    try {
        const participantId = getParticipantId();
        const endpoint = `/study/save-igt/${participantId}`;
        
        const result = await apiCall(endpoint, 'POST', {
            trials: igt.trials,
            finalBalance: igt.balance,
        });
        
        saveToStorage('igt_results', igt);
        
        return result;
    } catch (error) {
        showNotification('Erro ao salvar resultados do IGT', 'error');
        throw error;
    }
}

// ===== SALVAMENTO AUTOMÁTICO =====

/**
 * Configurar salvamento automático de formulário
 */
function setupAutoSave(formId, storageKey, debounceMs = 1000) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    let debounceTimer;
    
    form.addEventListener('change', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            saveToStorage(storageKey, data);
            showNotification('Respostas salvas automaticamente', 'success');
        }, debounceMs);
    });
    
    // Recuperar dados salvos
    const savedData = getFromStorage(storageKey);
    if (savedData) {
        Object.keys(savedData).forEach(key => {
            const input = form.elements[key];
            if (input) {
                if (input.type === 'checkbox' || input.type === 'radio') {
                    input.checked = savedData[key] === 'on' || savedData[key] === 'true';
                } else {
                    input.value = savedData[key];
                }
            }
        });
    }
}

/**
 * Salvar antes de sair da página
 */
function setupBeforeUnloadSave(storageKey) {
    window.addEventListener('beforeunload', () => {
        const form = document.querySelector('form');
        if (form) {
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            saveToStorage(storageKey, data);
        }
    });
}

// ===== PAINEL ADMINISTRATIVO =====

/**
 * Carregar métricas do painel
 */
async function loadMetrics() {
    try {
        const metrics = await apiCall('/admin/metrics');
        
        // Atualizar elementos no DOM
        document.getElementById('totalVisits').textContent = metrics.totalVisits;
        document.getElementById('totalCompleted').textContent = metrics.totalCompleted;
        document.getElementById('completionRate').textContent = metrics.completionRate.toFixed(1) + '%';
        document.getElementById('averageDuration').textContent = metrics.averageDuration.toFixed(1) + ' min';
        
        return metrics;
    } catch (error) {
        console.error('Erro ao carregar métricas:', error);
    }
}

/**
 * Carregar lista de participantes
 */
async function loadParticipants() {
    try {
        const participants = await apiCall('/admin/participants');
        
        const tableBody = document.getElementById('participantsTable');
        if (!tableBody) return;
        
        tableBody.innerHTML = '';
        
        participants.forEach(p => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${p.participantId}</td>
                <td>${p.deviceType}</td>
                <td>${p.browser}</td>
                <td>${p.state || 'N/A'}</td>
                <td>${p.status}</td>
                <td>${p.duration ? p.duration.toFixed(1) : 'N/A'} min</td>
                <td>${new Date(p.createdAt).toLocaleDateString('pt-BR')}</td>
            `;
            tableBody.appendChild(row);
        });
        
        return participants;
    } catch (error) {
        console.error('Erro ao carregar participantes:', error);
    }
}

/**
 * Exportar dados
 */
async function exportData(tableName, format = 'json') {
    try {
        const endpoint = `/admin/export/${tableName}?format=${format}`;
        const data = await apiCall(endpoint);
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${tableName}_${new Date().toISOString().split('T')[0]}.${format}`;
        a.click();
        
        showNotification(`Dados exportados com sucesso`, 'success');
    } catch (error) {
        showNotification(`Erro ao exportar dados`, 'error');
        console.error(error);
    }
}

// ===== INICIALIZAÇÃO =====

document.addEventListener('DOMContentLoaded', () => {
    // Verificar se participantId existe
    const participantId = getParticipantId();
    if (!participantId && !window.location.pathname.includes('index.html') && window.location.pathname !== '/') {
        // Redirecionar para home se não houver participantId
        // window.location.href = '/';
    }
});
